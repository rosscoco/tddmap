
var success = [];
var fail = [];
var sitesArray = [];
	var timeTillNextLoad = 1/4 * 1000

function initMap()
{	

	var terminalData;
	var siteData;
	var site;

	var geocoder = new google.maps.Geocoder();

	for ( var terminalName in allSiteData )
	{
		terminalData = allSiteData[ terminalName ];

		for ( var location in terminalData )
		{
			site = new SiteData( location, terminalData[ location ] );
			site.geocoder = geocoder;
			sitesArray.push( site );
		}
	}

	getNextLocation();


}


function getNextLocation()
{
	var nextSite = sitesArray.pop();

	if ( sitesArray.length > 0 ) 	nextSite.getLatLon( onSiteGeocoded )
	else							nextSite.getLatLon( onLastSiteGeocoded )
	
}

function onSiteGeocoded( site, result )
{
	console.log( 'Site geocoded' );

	if ( result == "OK" )
	{
		success.push( site );
	}
	else
	{
		fail.push( site );
	}

	if ( sitesArray.length > 0 )
	{
		setTimeout( getNextLocation, timeTillNextLoad );
	}
}

function onLastSiteGeocoded( site, result )
{
	onSiteGeocoded( site, result );

	success.forEach( function( site )
	{
		console.log(JSON.stringify(site))
	});
}


function SiteData( where, dataObj )
{
	this.data = dataObj
	this.data.postcode = where
}


SiteData.prototype.getLatLon = function( onComplete )
{
	this.onComplete = onComplete
	var site = this;

	this.geocoder.geocode( {address:this.data.postcode}, function( results, status )
	{
		site.onGeocodeSuccess( results, status );
	});
}

SiteData.prototype.onGeocodeSuccess = function(results, status )
{
	console.log("Geocoded " + this.data.postcode + " with status of " + status )

	this.onComplete( this );

	if ( status )
	{
		this.data.lat = results[0].geometry.location.lat();
		this.data.lat = results[0].geometry.location.lng();
	}
}


SiteData.prototype.toJSON = function()
{
	return { 	name:this.data.names[0], 
				allNames:this.data.names, 
				terminal:this.data.terminal, 
				isUK:this.data.isUKFuels, 
				isKey:this.data.isKeyFuels,
				lat:this.data.lat,
				long:this.long }
}

