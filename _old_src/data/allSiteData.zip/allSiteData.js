var allSiteData = {
  "Aberdeen Caledonian": {
    "IV30 4LF": {
      "name": "AITKENHEAD BUCCANEER S/STATION",
      "allNames": [
        "AITKENHEAD BUCCANEER S/STATION"
      ],
      "terminal": "Aberdeen Caledonian",
      "isUK": false,
      "isKey": false
    },
    "IV30 6BG": {
      "name": "AITKENHEAD NEW ELGIN S/STATION",
      "allNames": [
        "AITKENHEAD NEW ELGIN S/STATION"
      ],
      "terminal": "Aberdeen Caledonian",
      "isUK": false,
      "isKey": false
    },
    "IV32 7LH": {
      "name": "MOSSTODLOCH SERVICE STATION",
      "allNames": [
        "MOSSTODLOCH SERVICE STATION"
      ],
      "terminal": "Aberdeen Caledonian",
      "isUK": false,
      "isKey": false
    }
  },
  "Birmingham": {
    "B11 2HA": {
      "name": "MALEK GREET F STN",
      "allNames": [
        "MALEK GREET F STN",
        "KEMPSTON GREET F STN"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": false
    },
    "B18 4HB": {
      "name": "MAAN DUDLEY ROAD S STN",
      "allNames": [
        "MAAN DUDLEY ROAD S STN",
        "KEYFUELS D DUDLEY ROAD S STN",
        "UK FUELS D DUDLEY ROAD SS"
      ],
      "terminal": "Birmingham",
      "isUK": true,
      "isKey": true
    },
    "B47 5QJ": {
      "name": "WIDALL TRUEMANS HEATH FILLING STN",
      "allNames": [
        "WIDALL TRUEMANS HEATH FILLING STN"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": false
    },
    "B66 2RX": {
      "name": "CHANCO CRANFORD ST S STN",
      "allNames": [
        "CHANCO CRANFORD ST S STN"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": false
    },
    "B69 3DS": {
      "name": "PENI SANDWELL SERVICE STATION",
      "allNames": [
        "PENI SANDWELL SERVICE STATION"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": false
    },
    "B9 5NS": {
      "name": "MALEK BORDESLEY GREEN S STN",
      "allNames": [
        "MALEK BORDESLEY GREEN S STN"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": false
    },
    "CV3 4EX": {
      "name": "KEYFUELS D MRH RYTON",
      "allNames": [
        "KEYFUELS D MRH RYTON",
        "MRH RYTON"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": true
    },
    "DY5 1SY": {
      "name": "MRH MERRYHILL",
      "allNames": [
        "MRH MERRYHILL",
        "KEYFUELS D MRH MERRYHILL"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": true
    },
    "GL1 3HB": {
      "name": "SYMONDS LONDON RD S STN",
      "allNames": [
        "SYMONDS LONDON RD S STN"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": false
    },
    "NN17 2AE": {
      "name": "BROBOT CORBY NORTH",
      "allNames": [
        "BROBOT CORBY NORTH"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": false
    },
    "NN18 8TJ": {
      "name": "KEYFUELS D BROBOT SOUTHERN GATEWAY",
      "allNames": [
        "KEYFUELS D BROBOT SOUTHERN GATEWAY",
        "BROBOT CORBY SOUTHERN GATEWAY"
      ],
      "terminal": "Birmingham",
      "isUK": false,
      "isKey": true
    }
  },
  "Bramhall": {
    "BB1 3HQ": {
      "name": "UK FUELS D FURTHERGATE SS",
      "allNames": [
        "UK FUELS D FURTHERGATE SS"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "BB4 5PD": {
      "name": "HIGHSHOT HASLINGDEN S STN",
      "allNames": [
        "HIGHSHOT HASLINGDEN S STN"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "BD16 2RD": {
      "name": "KEYFUELS D MALTHURST RANKIN",
      "allNames": [
        "KEYFUELS D MALTHURST RANKIN",
        "MRH RANKIN F STN"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    },
    "BL6 5UZ": {
      "name": "KEYFUELS D RIVINGTON NORTH S/STN",
      "allNames": [
        "KEYFUELS D RIVINGTON NORTH S/STN",
        "KEYFUELS D RIVINGTON SOUTH S/STN"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    },
    "BL9 7HY": {
      "name": "CROWN D BR",
      "allNames": [
        "CROWN D BR"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "CA10 3SS": {
      "name": "UK FUELS D M6 DIESEL TEBAY",
      "allNames": [
        "UK FUELS D M6 DIESEL TEBAY",
        "KEYFUELS D M6 DIESEL TEBAY"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": true
    },
    "CA11 7EH": {
      "name": "UK FUELS D ULLSWATER ROAD",
      "allNames": [
        "UK FUELS D ULLSWATER ROAD"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "CA11 9EH": {
      "name": "UK FUELS D PENRITH TRUCK STOP",
      "allNames": [
        "UK FUELS D PENRITH TRUCK STOP",
        "KEYFUELS D PENRITH TRUCK STOP"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": true
    },
    "CA4 0AN": {
      "name": "UK FUELS D GOLDEN FLEECE SS",
      "allNames": [
        "UK FUELS D GOLDEN FLEECE SS",
        "KEYFUELS D GOLDEN FLEECE SS"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": true
    },
    "CA6 4DT": {
      "name": "UK FUELS D HARKER SS",
      "allNames": [
        "UK FUELS D HARKER SS"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "CH1 6LZ": {
      "name": "WIRRAL FUELS D BR",
      "allNames": [
        "WIRRAL FUELS D BR"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "CH7 2NJ": {
      "name": "BLAKEMORE BUCKLEY",
      "allNames": [
        "BLAKEMORE BUCKLEY"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "DE45 1AW": {
      "name": "MFG PARK VIEW S STN",
      "allNames": [
        "MFG PARK VIEW S STN",
        "UK FUELS D PARK VIEW S STN"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "HX4 8BQ": {
      "name": "PATEL WEST VALE F STN FOR",
      "allNames": [
        "PATEL WEST VALE F STN FOR"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "L33 3AY": {
      "name": "MATALAN KNOWSLEY D BR",
      "allNames": [
        "MATALAN KNOWSLEY D BR"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "L33 7XS": {
      "name": "UK FUELS D GOODWIN CORP",
      "allNames": [
        "UK FUELS D GOODWIN CORP",
        "KEYFUELS D GOODWIN CORP",
        "STANDARD FUELS D BR"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": true
    },
    "L5 9TE": {
      "name": "KEYFUELS D QUAY FUELS",
      "allNames": [
        "KEYFUELS D QUAY FUELS"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    },
    "L5 9ZA": {
      "name": "UK FUELS D COUNTY OILS",
      "allNames": [
        "UK FUELS D COUNTY OILS",
        "COUNTY D BR"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "LA2 9DU": {
      "name": "KEYFUELS D MOTO FORTON NORTH",
      "allNames": [
        "KEYFUELS D MOTO FORTON NORTH",
        "KEYFUELS D MOTO FORTON SOUTH"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    },
    "LA5 9RQ": {
      "name": "KEYFUELS D TRUCKHAVEN",
      "allNames": [
        "KEYFUELS D TRUCKHAVEN"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    },
    "LA7 7NX": {
      "name": "UK FUELS D M6 DIESEL CROOKLANDS",
      "allNames": [
        "UK FUELS D M6 DIESEL CROOKLANDS"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "LL3 1YR": {
      "name": "UK FUELS D MOSTYN BROADWAY S STN",
      "allNames": [
        "UK FUELS D MOSTYN BROADWAY S STN",
        "KEYFUELS D MOSTYN BROADWAY S STN"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": true
    },
    "LL30 1YR": {
      "name": "UK FUEL LTD MOSTYN BROADWAY S STN",
      "allNames": [
        "UK FUEL LTD MOSTYN BROADWAY S STN"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "LS28 9AY": {
      "name": "PATEL WHARRELS S STN",
      "allNames": [
        "PATEL WHARRELS S STN",
        "UK FUELS D WHARRELS SERVICE STATION"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "LS8 5DT": {
      "name": "PATEL ROSEVILLE S STN",
      "allNames": [
        "PATEL ROSEVILLE S STN",
        "KEYFUELS D ROSEVILLE SS",
        "UK FUELS D ROSEVILLE SS"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": true
    },
    "M17 1JL": {
      "name": "UK FUELS D TRAFFORD PARK S STN",
      "allNames": [
        "UK FUELS D TRAFFORD PARK S STN"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "M17 1PG": {
      "name": "KEYFUELS D TRAFFORD PARK SS",
      "allNames": [
        "KEYFUELS D TRAFFORD PARK SS"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    },
    "M32 0YQ": {
      "name": "KEYFUELS D TURNERS SOHAM LTD",
      "allNames": [
        "KEYFUELS D TURNERS SOHAM LTD"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    },
    "PR4 0XB": {
      "name": "MASTER ENTERPRIZE LEA GATE S STN",
      "allNames": [
        "MASTER ENTERPRIZE LEA GATE S STN"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "PR5 8AN": {
      "name": "UK FUELS D RIBBLE FUELS",
      "allNames": [
        "UK FUELS D RIBBLE FUELS"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": false
    },
    "PR9 8BY": {
      "name": "HERMON HODGE D BR BANKS",
      "allNames": [
        "HERMON HODGE D BR BANKS"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "S2 1GE": {
      "name": "PETROGAS SHEFFIELD S/STATION",
      "allNames": [
        "PETROGAS SHEFFIELD S/STATION"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "S43 1DE": {
      "name": "MFG BRIMINGTON S STN",
      "allNames": [
        "MFG BRIMINGTON S STN"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "ST10 1JF": {
      "name": "STODDARDS D BR",
      "allNames": [
        "STODDARDS D BR"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "WA7 3EZ": {
      "name": "KEYFUELS D M56 COUNTY OILS",
      "allNames": [
        "KEYFUELS D M56 COUNTY OILS",
        "UK FUELS D M56 DERV STOP",
        "COUNTY D BR RUNCORN"
      ],
      "terminal": "Bramhall",
      "isUK": true,
      "isKey": true
    },
    "WA9 3EZ": {
      "name": "CALDO OILS D BR",
      "allNames": [
        "CALDO OILS D BR"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": false
    },
    "WF83HU": {
      "name": "KEYFUELS D DARRINGTON S/STATION",
      "allNames": [
        "KEYFUELS D DARRINGTON S/STATION"
      ],
      "terminal": "Bramhall",
      "isUK": false,
      "isKey": true
    }
  }
}